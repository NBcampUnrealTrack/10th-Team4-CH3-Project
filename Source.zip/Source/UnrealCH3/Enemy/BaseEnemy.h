// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "BaseEnemy.generated.h"


UENUM(BlueprintType)
enum class EEnemyState : uint8
{
    Idle,
    Patrol,
    Chase,
    Attack,
    Hit,
    Dead
};

UENUM(BlueprintType)
enum class EEnemyAttackType : uint8
{
    Melee,
    Ranged
};

UCLASS()
class UNREALCH3_API ABaseEnemy : public ACharacter
{
    GENERATED_BODY()

public:
    // Sets default values for this character's properties
    ABaseEnemy();
    virtual void BeginPlay() override;
    virtual float TakeDamage(float DamageAmount, struct FDamageEvent const& DamageEvent, AController* EventInstigator, AActor* DamageCauser) override;
    //virtual void Attack();
    virtual void Die();
    bool IsTargetInAttackRange() const;
    /*bool IsTargetInDetectRange() const;
    void SetEnemyState(EEnemyState NewState);*/
    EEnemyState GetEnemyState() const;
    void SetTargetActor(AActor* NewTarget);
    //AActor* GetTargetActor() const;
    virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
    float GetViewingAngle();
    float GetViewingDistance();
    float GetAttackMaxRange();
    float GetAttackDamage();
    int GetScore();
    float GetExp();

protected:
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float MaxHP;            // �ִ� ü��

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float CurrentHP;        // ���� ü��

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float AttackDamage;     // ���ݷ�

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float AttackMaxRange;   // �ִ� ���� ��Ÿ�

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float AttackMinRange;   // �ּ� ���� ��Ÿ�

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float Defense;          // ����

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float Exp;              // ȹ�� ����ġ

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    int Score;            // óġ ����

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float ViewingAngle;     // �þ߰�

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float ViewingDistance;  // �þ� ���� �Ÿ�

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float HearingDistance;  // û�� ���� �Ÿ�

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float TargetChangeTime; // Ÿ�� ���� ��� �ð�

    FTimerHandle TargetChangeTimer;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    AActor* TargetActor;    // ���� ���� ���� Ÿ��(��ǥ)

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float AttackCoolTime;   // ���� ��Ÿ��

    FTimerHandle AttackCoolTimer;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float WarningTime;      // ���� �� ��� �ð�

    FTimerHandle WarningTimer;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    bool bIsDead = false;           // ��� ����

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Stats")
    EEnemyState CurrentState = EEnemyState::Idle;   // ���� ����
};